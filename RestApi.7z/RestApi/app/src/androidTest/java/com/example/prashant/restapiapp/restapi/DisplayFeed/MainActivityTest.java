package com.example.prashant.restapiapp.restapi.DisplayFeed;

import android.support.test.espresso.Espresso;
import android.support.test.rule.ActivityTestRule;


import com.example.fatty.restapiapp.utility.EspressoIdlingResource;
import com.example.prashant.restapiapp.R;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.action.ViewActions.swipeDown;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

/**
 * Created by FATTY on 2/8/2018.
 */
public class MainActivityTest {

    @Rule
    public ActivityTestRule<MainActivity> mActivity = new ActivityTestRule<MainActivity>(MainActivity.class);
    @Before
    public void setUp() throws Exception {
        Espresso.registerIdlingResources(EspressoIdlingResource.getIdlingResource());
    }

    @After
    public void tearDown() throws Exception {
       Espresso.unregisterIdlingResources(EspressoIdlingResource.getIdlingResource());
    }
    @Test
    public void testError(){
        Espresso.onView(withId(R.id.swipelayout)).perform(swipeDown());

       // Espresso.onView(withId(R.id.txtView)).check(matches(isDisplayed()));
        Espresso.onView(withId(R.id.list_item)).check(matches(isDisplayed()));
    }

}