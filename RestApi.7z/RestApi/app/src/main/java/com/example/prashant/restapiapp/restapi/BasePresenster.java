package com.example.prashant.restapiapp.restapi;


public interface BasePresenster {
    void start();
}
