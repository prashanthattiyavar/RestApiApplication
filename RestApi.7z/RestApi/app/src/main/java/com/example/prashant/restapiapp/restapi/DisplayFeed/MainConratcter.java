package com.example.prashant.restapiapp.restapi.DisplayFeed;


import com.example.prashant.restapiapp.restapi.BasePresenster;
import com.example.prashant.restapiapp.restapi.BaseView;
import com.example.prashant.restapiapp.restapi.utility.Place;
import com.example.prashant.restapiapp.restapi.utility.Place;



public interface MainConratcter {
    interface View extends BaseView<Presenter> {
        void showResult(Place result);
        void showError(String err);

    }

    interface Presenter extends BasePresenster {
        void fetchData();

    }
}
