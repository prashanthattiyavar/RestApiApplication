package com.example.prashant.restapiapp.restapi.utility;

import java.io.Serializable;

/**
 * Created by FATTY on 2/1/2018.
 */

public class Place implements Serializable{
    public String title;
    public Rows[] rows;

    public Place() {

    }
}
