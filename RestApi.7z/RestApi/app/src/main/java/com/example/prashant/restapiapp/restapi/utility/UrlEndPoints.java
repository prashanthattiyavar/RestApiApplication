package com.example.prashant.restapiapp.restapi.utility;

/**
 * Created by brajabasi on 10-04-2016.
 */
public class UrlEndPoints {
    public static final String URL_DROPBOX= "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json";

}
