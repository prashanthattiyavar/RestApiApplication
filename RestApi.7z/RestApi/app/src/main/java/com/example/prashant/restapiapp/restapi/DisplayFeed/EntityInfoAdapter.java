package com.example.prashant.restapiapp.restapi.DisplayFeed;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.prashant.restapiapp.R;
import com.example.prashant.restapiapp.restapi.utility.*;

public class EntityInfoAdapter extends BaseAdapter {
    private Rows[] mEntityInfos;
    private Context mContext;
    public EntityInfoAdapter(Context context, Rows[] entityInfos) {
        mContext = context;
        mEntityInfos = entityInfos;
    }

    public void setData(Rows[] entityInfos) {
        mEntityInfos = entityInfos;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mEntityInfos.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.listviewrow ,parent, false);
            viewHolder = new ViewHolder();
            viewHolder.infoTitle = (TextView)convertView.findViewById(R.id.title);
            viewHolder.infoDescription = (TextView)convertView.findViewById(R.id.description);
            viewHolder.icon = (ImageView) convertView.findViewById(R.id.icon);
            viewHolder.rightArrow = (ImageView) convertView.findViewById(R.id.next);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        Rows entityInfo = mEntityInfos[position];
        viewHolder.infoTitle.setText(entityInfo.title);
        viewHolder.infoDescription.setText(entityInfo.description);
        Glide.with(mContext)
                .load(entityInfo.imageHref).placeholder(R.drawable.ic_launcher_background)
                .into(viewHolder.icon);

        return convertView;

    }


    static class ViewHolder {

        TextView infoTitle;
        TextView infoDescription;
        ImageView icon;
        ImageView rightArrow;
    }

}
