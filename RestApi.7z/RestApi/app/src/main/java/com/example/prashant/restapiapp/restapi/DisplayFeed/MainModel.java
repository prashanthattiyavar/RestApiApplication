package com.example.prashant.restapiapp.restapi.DisplayFeed;

import android.os.AsyncTask;
import android.os.Message;

import com.squareup.okhttp.Headers;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import java.io.IOException;


public class MainModel {
    interface iResultCallback{
        void setResult(String res);
    }
    private iResultCallback mCallback;
    private String dataHeader;
    private String dataBody;

    public MainModel(iResultCallback callback) {
        mCallback = callback;
    }

    public void resquestData(){

    }

    private class LoadDataTask extends AsyncTask<Void,Void,Message> {

        @Override
        protected void onPreExecute() {
            //resetView();
            super.onPreExecute();
        }

        @Override
        protected Message doInBackground(Void... voids) {
            OkHttpClient okHttpClient = new OkHttpClient();
            Request.Builder requestBuilder = new Request.Builder();
            Request request = requestBuilder.url("http://date.jsontest.com/")
                    .build();

            Message msg = new Message();

            try {
                Response response = okHttpClient.newCall(request).execute();
                if(response.isSuccessful()){
                    msg.what = 1;
                    msg.obj = response;
                } else {
                    msg.what = 0;
                    msg.obj = "Not Success\ncode : " + response.code();
                }
            } catch (IOException e) {
                e.printStackTrace();
                msg.what = 0;
                msg.obj  = "Error\n" + e.getMessage();
            }
            return msg;
        }

        @Override
        protected void onPostExecute(Message message) {
            super.onPostExecute(message);
            switch(message.what) {
                case 0:
                  //  mResult.setText((String)message.obj);
                    break;
                case 1:
                    parseResponseData((Response)message.obj);
                    //mResult.setText(dataHeader + "\n" + dataBody);
                    //showView();
                    break;
            }
        }
    }

    private void parseResponseData(Response obj) {
        Headers headers = obj.headers();
        for(String header:headers.names()){
            dataHeader+= "name:" + header + "\n" + "value:" + headers.get(header) + "\n" ;
        }

        try {
            dataBody = obj.body().string();
        } catch (IOException e) {
            e.printStackTrace();
            dataBody = "Error !\n\n" + e.getMessage();
        }


    }

}
