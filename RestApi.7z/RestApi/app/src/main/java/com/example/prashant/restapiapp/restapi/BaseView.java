package com.example.prashant.restapiapp.restapi;

public interface BaseView<T> {
    void setPresenter(T presenter);
}
