package com.example.prashant.restapiapp.restapi.data.source.remote;

import android.support.annotation.NonNull;


import com.example.prashant.restapiapp.restapi.data.source.RawDataSource;
import com.example.prashant.restapiapp.restapi.utility.Place;
import com.example.prashant.restapiapp.restapi.utility.UrlEndPoints;
import com.example.prashant.restapiapp.restapi.data.source.RawDataSource;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import java.util.concurrent.Callable;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class RawDataRemoteSource implements  RawDataSource {
    private static RawDataRemoteSource INSTANCE;
    private LoadRawDataCallback mCallback;

    private String dataHeader;
    private String dataBody;

    private RawDataRemoteSource() {}

    public static RawDataRemoteSource getInstance() {
        if (INSTANCE == null ) {
            INSTANCE = new RawDataRemoteSource();
        }
        return INSTANCE;
    }


    @Override
    public void getRawData(@NonNull LoadRawDataCallback callback) {
        mCallback = callback;
        // Call AsynTask
       // new LoadDataTask().execute();
        Observable<Place> observable = Observable.fromCallable(callable)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        observable.subscribe(s->mCallback.onRawDataLoaded(s),
                throwable -> mCallback.onDataNotAvailable("Error:No Data!!!" + throwable.getMessage()));
    }


    private Callable<Place> callable = new Callable<Place>() {
        @Override
        public Place call() throws Exception {
            OkHttpClient okHttpClient = new OkHttpClient();
            Request.Builder requestBuilder = new Request.Builder();
            Request request = requestBuilder.url(UrlEndPoints.URL_DROPBOX)
                    .build();

            Response response = okHttpClient.newCall(request).execute();
            Place place = ParseJson(response.body().string());
            return place;
        }
    };

    private Place ParseJson(String responseBody){

        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        Place place = gson.fromJson(responseBody,Place.class);
        return place;
    }

}
