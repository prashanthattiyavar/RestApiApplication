package com.example.prashant.restapiapp.restapi.DisplayFeed;

import android.support.annotation.NonNull;

import com.example.prashant.restapiapp.restapi.data.source.RawDataSource;
import com.example.prashant.restapiapp.restapi.utility.Place;
import com.example.prashant.restapiapp.restapi.data.source.RawDataSource;
import com.example.prashant.restapiapp.restapi.utility.Place;




public class MainPresenter implements MainConratcter.Presenter {
    private RawDataSource mDataSource;
    private MainConratcter.View mView;
    public MainPresenter(@NonNull MainConratcter.View mainView, @NonNull RawDataSource dataSource) {
        mView = mainView;
        mDataSource = dataSource;
    }
    @Override
    public void start() {

    }

    @Override
    public void fetchData() {
        mDataSource.getRawData(new RawDataSource.LoadRawDataCallback() {
            @Override
            public void onRawDataLoaded(Place data) {
                mView.showResult(data);
            }

                      @Override
            public void onDataNotAvailable(String err) {
                mView.showError(err);
            }
        });

    }


}
