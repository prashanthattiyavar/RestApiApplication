package com.example.prashant.restapiapp.restapi.data.source;

import android.support.annotation.NonNull;

import com.example.prashant.restapiapp.restapi.utility.Place;

public interface RawDataSource {
     interface LoadRawDataCallback{
         void onRawDataLoaded(Place data);
         void onDataNotAvailable(String err);
     }

     public void getRawData(@NonNull LoadRawDataCallback callback);
}
