package com.example.prashant.restapiapp.restapi.DisplayFeed;

import android.os.PersistableBundle;
import android.support.annotation.VisibleForTesting;
import android.support.test.espresso.IdlingResource;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.prashant.restapiapp.restapi.data.source.remote.RawDataRemoteSource;
import com.example.prashant.restapiapp.R;
import com.example.prashant.restapiapp.restapi.utility.Place;
import com.example.prashant.restapiapp.restapi.utility.Rows;
import com.example.fatty.restapiapp.utility.EspressoIdlingResource;
public class MainActivity extends AppCompatActivity implements MainConratcter.View {
   // private Button mGetData;
    private TextView mResult;
    private ListView mListView;
    private MainConratcter.Presenter mMainPresenter;
    private EntityInfoAdapter mEntityInfoAdapter;
    private EntityRecyclerViewAdapter mRecyclerViewAdapter;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private Place mPlaceData = null;
    private final String PLACE_DATA = "Place";
    private RecyclerView mRecycleList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast.makeText(getApplicationContext(),"Pull down to refresh....",Toast.LENGTH_LONG).show();
       // mGetData = (Button)findViewById(R.id.btnGet);
        mResult = (TextView)findViewById(R.id.txtView);
     //   mListView = (ListView)findViewById(R.id.list_item);
        mRecycleList = (RecyclerView)findViewById(R.id.recyllist);
        if (savedInstanceState != null) {
            mPlaceData = (Place) savedInstanceState.getSerializable(PLACE_DATA);
        }
        if(mPlaceData != null) {
           getSupportActionBar().setTitle(mPlaceData.title);
         //   mEntityInfoAdapter = new EntityInfoAdapter(this, mPlaceData.rows);
            mRecyclerViewAdapter = new EntityRecyclerViewAdapter(this,mPlaceData.rows);
        } else {

           // mEntityInfoAdapter = new EntityInfoAdapter(this, new Rows[0]);
            mRecyclerViewAdapter = new EntityRecyclerViewAdapter(this,new Rows[0]);
        }

        mRecycleList.setAdapter(mRecyclerViewAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mRecycleList.setLayoutManager(linearLayoutManager);

        mMainPresenter = new MainPresenter(this, RawDataRemoteSource.getInstance());
        mSwipeRefreshLayout = (SwipeRefreshLayout)findViewById(R.id.swipelayout);
        mSwipeRefreshLayout.setColorSchemeColors(
                ContextCompat.getColor(this, R.color.colorPrimary),
                ContextCompat.getColor(this, R.color.colorAccent),
                ContextCompat.getColor(this, R.color.colorPrimaryDark)
        );

        // Set the scrolling view in the custom SwipeRefreshLayout.
        //mSwipeRefreshLayout.setScrollUpChild(listView);

        mSwipeRefreshLayout.setOnRefreshListener(() ->{

            EspressoIdlingResource.increment();
            mMainPresenter.fetchData();
        });


    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putSerializable(PLACE_DATA,mPlaceData);
    }

    private void resetView() {
        mResult.setVisibility(View.GONE);
        mResult.setText("");
    }

    private void showView() {
        mResult.setVisibility(View.GONE);
      //  mListView.setVisibility(View.VISIBLE);
    }
    private void showError() {
        mResult.setVisibility(View.VISIBLE);
        //mListView.setVisibility(View.GONE);
    }

    @Override
    public void setPresenter(MainConratcter.Presenter presenter) {
        mMainPresenter = presenter;
    }

    @Override
    public void showResult(Place result) {

        mPlaceData= result;
        getSupportActionBar().setTitle(result.title);
        //getActionBar().setTitle(result.title);
       // mEntityInfoAdapter.setData(result.rows);
        mRecyclerViewAdapter.setData(result.rows);
        // stopping swipe refresh
        mSwipeRefreshLayout.setRefreshing(false);
        showView();

        if (!EspressoIdlingResource.getIdlingResource().isIdleNow()) {
            EspressoIdlingResource.decrement(); // Set app as idle.
        }
    }

    @Override
    public void showError(String err) {
        mResult.setText(err);
        // stopping swipe refresh
        mSwipeRefreshLayout.setRefreshing(false);
        showError();

        if (!EspressoIdlingResource.getIdlingResource().isIdleNow()) {
            EspressoIdlingResource.decrement(); // Set app as idle.
        }
    }


    @VisibleForTesting
    public IdlingResource getCountingIdlingResource() {
        return EspressoIdlingResource.getIdlingResource();
    }
}
