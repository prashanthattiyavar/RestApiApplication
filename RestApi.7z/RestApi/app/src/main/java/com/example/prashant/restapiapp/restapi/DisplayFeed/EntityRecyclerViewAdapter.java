package com.example.prashant.restapiapp.restapi.DisplayFeed;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.prashant.restapiapp.R;
//import com.example.prashant.restapiapp.restapi.R;
import com.example.prashant.restapiapp.restapi.utility.Rows;

public class EntityRecyclerViewAdapter extends RecyclerView.Adapter<EntityRecyclerViewAdapter.EntityViewHolder> {
    private Rows[] mEntityInfos;
    private Context mContext;
    EntityRecyclerViewAdapter(Context ctx, Rows[] entityInfos) {
        mEntityInfos = entityInfos;
        mContext =ctx;
    }



    @Override
    public EntityRecyclerViewAdapter.EntityViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.listviewrow,parent,false);
        return new EntityViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EntityRecyclerViewAdapter.EntityViewHolder holder, int position) {
           Rows entityInfo = mEntityInfos[position];
        holder.infoTitle.setText(entityInfo.title);
        holder.infoDescription.setText(entityInfo.description);
        Glide.with(mContext)
                .load(entityInfo.imageHref).placeholder(R.drawable.ic_launcher_background)
                .into(holder.icon);

    }

    @Override
    public int getItemCount() {
        return mEntityInfos.length;
    }

    public void setData(Rows[] data) {
        mEntityInfos = data;
        notifyDataSetChanged();
    }


    class EntityViewHolder extends RecyclerView.ViewHolder {
       TextView infoTitle;
       TextView infoDescription;
       ImageView icon;
       ImageView rightArrow;

       public EntityViewHolder(View itemView) {
           super(itemView);

           infoTitle = (TextView)itemView.findViewById(R.id.title);
           infoDescription = (TextView)itemView.findViewById(R.id.description);
           icon = (ImageView) itemView.findViewById(R.id.icon);
           rightArrow = (ImageView) itemView.findViewById(R.id.next);
       }
   }
}
